// Uji UI mode Driver di browser sungguhan. Jalankan: npm run serve (terminal lain) lalu node test/ui-driver.mjs
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
let chromium;
try { ({ chromium } = require('playwright')); } catch { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
import assert from 'node:assert/strict';

const BASE = process.env.BASE || 'http://localhost:8080/';
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, geolocation: { latitude: -7.2625, longitude: 112.7381 }, permissions: ['geolocation'] });
const page = await ctx.newPage();
const errors = [], external = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('dialog', d => d.accept());
page.on('request', r => { if (!r.url().startsWith(BASE) && !r.url().startsWith('data:')) external.push(r.url()); });
const text = () => page.locator('#app').innerText();
const click = sel => page.locator(sel).first().click();
const tid = id => `[data-testid="${id}"]`;
const menu = async act => { await click('[data-act=menu]'); await click(`.mn [data-act=${act}]`); };
let step = 0; const ok = m => console.log(`ok ${++step} - ${m}`);
const toastText = () => page.locator('#toast').innerText();

await page.goto(BASE); await page.evaluate(() => localStorage.clear()); await page.reload();
assert.match(await text(), /Saya Driver/); ok('layar peran punya pilihan Driver');

// ---- Pembeli membuat pesanan Antar (alamat + bayar tunai) ----
await click('[data-role=pembeli]');
await click('[data-act=profile]'); await page.fill('#p_alamat', 'Jl. Kertajaya No. 10, Gubeng, Surabaya'); await click('[data-act=saveProfile]');
await page.evaluate(() => document.querySelector('[data-testid=profile-check-location-btn]'));
await click(tid('profile-check-location-btn')); await page.waitForTimeout(800);
await click('[data-act=back]');
await click(tid('home-order-btn-L2'));
await click(tid('confirm-delivery-tab-antar'));
await click(tid('confirm-payment-tab-tunai'));
await page.fill('#c_catatan', 'Pagar hijau, tolong telepon');
await click(tid('confirm-pay-btn'));
assert.match(await text(), /Pesanan Berhasil/); ok('pembeli membuat pesanan Antar tunai');
const code = (await page.locator(tid('order-code')).innerText()).trim();
assert.match(code, /^[A-Z2-9]{6}$/);

// ---- Driver: lihat order + lokasi pembeli ----
await menu('roles'); await click('[data-role=driver]');
await page.waitForTimeout(300);
let t = await text();
assert.match(t, /Order Antar/); assert.match(t, /1 order tersedia/); ok('driver melihat 1 order tersedia');
assert.match(t, /Donat Cokelat Kacang/); assert.match(t, /J\.CO Donuts/); assert.match(t, /Jl\. Kertajaya No\. 10/); ok('driver melihat toko (tempat ambil) dan alamat pembeli');
assert.match(t, /Tunai Rp/); assert.match(t, /Pagar hijau/); ok('metode bayar tunai dan catatan pembeli terlihat');
const feeTxt = await page.locator(tid('ddash-fee-O1')).innerText(); assert.match(feeTxt, /\+Rp/); ok('ongkir (pendapatan) terlihat');
const href = await page.locator(tid('ddash-store-route-O1')).getAttribute('href'); assert.match(href, /google\.com\/maps\/dir\/\?api=1&destination=-7\./); ok('tautan rute ke toko memakai koordinat toko');
assert.equal(await page.locator('.nav .nv').count(), 4); ok('4 tab driver: Order, Antaran, Riwayat, Akun');

// ---- Offline menyembunyikan order ----
await click(tid('ddash-online-toggle')); assert.match(await text(), /Kamu offline/); 
await click(tid('ddash-online-toggle')); assert.match(await text(), /1 order tersedia/); ok('toggle online/offline');

// ---- Terima ----
await click(tid('ddash-accept-btn-O1'));
t = await text();
assert.match(t, /Antaran Aktif/); assert.match(t, /Menuju toko/); assert.match(t, /Ambil di toko/); ok('terima order membuka tab Antaran');
assert.match(t, /Tagih tunai/); ok('driver diingatkan menagih tunai');
await click(tid('dactive-pickup-btn'));
assert.match(await text(), /baru bisa diambil pukul/); ok('pengambilan ditolak sebelum Jendela Ambil dibuka');

// ---- Toko melihat kurir ----
await menu('roles'); await page.selectOption('#storeSel', 's1'); await click('[data-role=toko]');
t = await text(); assert.match(t, /Kurir Driver Demo/); ok('toko melihat kurir yang menerima');
assert.equal(await page.locator(tid('tdash-deliver-btn')).count(), 0); ok('toko tidak lagi punya tombol Mulai Antar saat kurir ditugaskan');
await click(tid('tdash-prepare-btn')); assert.match(await text(), /Siap diambil kurir/); ok('toko menandai siap');

// ---- Driver ambil & berangkat (majukan jam agar Jendela Ambil dibuka) ----
await menu('roles'); await click('[data-role=driver]');
await menu('advance'); await page.waitForTimeout(200);
await click('[data-testid=bottom-nav-tab-dactive]');
assert.match(await text(), /Toko sudah menandai siap/); ok('driver melihat status toko siap');
await click(tid('dactive-pickup-btn'));
t = await text(); assert.match(t, /Dalam perjalanan/); assert.match(t, /Tiba sekitar/); ok('ambil pesanan & berangkat -> dalam perjalanan + ETA');
assert.ok(await page.locator(tid('dactive-scan-btn')).count()); ok('tombol scan serah terima tersedia');

// ---- Pembeli melihat kurir di tracking ----
await menu('roles'); await click('[data-role=pembeli]');
await click('[data-testid=bottom-nav-tab-orders]'); await click(tid('orders-row-O1'));
t = await text(); assert.match(t, /Kurir ditugaskan/); assert.match(t, /Driver Demo/); assert.match(t, /Dalam pengantaran/); ok('pembeli melihat kurir & status pengantaran');

// ---- Serah terima: kode salah, lalu benar ----
await menu('roles'); await click('[data-role=driver]');
await click('[data-testid=bottom-nav-tab-dactive]');
await click(tid('dactive-code-btn')); await page.fill('#kode', 'AAAAAA'); await click(tid('verify-sheet-submit-btn'));
assert.match(await page.locator('#flash').innerText(), /tidak ditemukan/); ok('kode salah ditolak');
await page.fill('#kode', code); await click(tid('verify-sheet-submit-btn'));
await page.waitForTimeout(200);
assert.match(await toastText(), /Serah terima berhasil/); assert.match(await toastText(), /Terima tunai/); ok('serah terima dengan kode berhasil, tunai ditagih');
assert.match(await text(), /Belum ada antaran aktif/); ok('antaran aktif kosong setelah selesai');

// ---- Riwayat ----
await click('[data-testid=bottom-nav-tab-dhist]');
t = await text(); assert.match(t, /Riwayat & Pendapatan/); assert.ok(await page.locator(tid('dhist-row-O1')).count());
const earn = await page.locator(tid('dhist-earnings')).innerText(); assert.match(earn, /^1\b/m); assert.match(earn, /Rp/); ok('riwayat dan pendapatan ongkir tampil');
assert.ok(await page.locator(tid('dhist-cash-note')).count()); ok('catatan tunai di riwayat');

// ---- Akun ----
await click('[data-testid=bottom-nav-tab-dakun]');
await page.fill('#d_nama', 'Budi Santoso'); await page.selectOption('#d_kendaraan', 'Motor'); await page.fill('#d_plat', 'l 4455 ab');
await click(tid('driver-save-btn')); assert.match(await text(), /Profil driver tersimpan/); assert.match(await text(), /Budi Santoso/); ok('profil driver tersimpan');
await click(tid('driver-sample-location-btn')); assert.match(await text(), /Tunjungan/); ok('titik contoh lokasi driver');

// ---- Pembeli menerima notifikasi dari kurir ----
await menu('roles'); await click('[data-role=pembeli]');
await click(tid('header-notifications-btn')); t = await text();
assert.match(t, /Kurir menerima pesananmu/); assert.match(t, /Pesanan diterima/); ok('pembeli mendapat notifikasi kurir & selesai');

// ---- Notifikasi driver ----
await click('[data-act=back]'); await menu('roles'); await click('[data-role=driver]'); await click(tid('header-notifications-btn'));
assert.match(await text(), /Notifikasi/); ok('driver punya layar notifikasi');

// ---- Persisten setelah muat ulang ----
await page.reload(); assert.match(await text(), /Notifikasi|Order Antar|Antaran/); ok('peran driver tersimpan setelah reload');

// ---- Izin: kamera/lokasi/notifikasi dapat diminta dari driver ----
await page.reload();
await menu('izin'); t = await text(); assert.match(t, /dipakai toko atau driver/); assert.ok(await page.locator('[data-testid^=permission-row-]').count() === 3); ok('Izin Aplikasi tersedia untuk driver');

assert.deepEqual(errors, [], 'galat konsol: ' + errors.join(' | ')); ok('tanpa galat konsol');
assert.deepEqual(external, [], 'permintaan eksternal: ' + external.join(' | ')); ok('tanpa permintaan jaringan eksternal');
await browser.close();
console.log(`\n${step} pemeriksaan UI driver lulus`);
