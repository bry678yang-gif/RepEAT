// Menyalin ikon launcher RepEAT (android-res/) ke proyek Android hasil "npx cap add android". Idempotent.
import fs from 'node:fs';
import path from 'node:path';

export function listFiles(dir, base = dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? listFiles(path.join(dir, e.name), base) : [path.relative(base, path.join(dir, e.name))]);
}
export function copyIcons(srcDir, resDir) {
  const files = listFiles(srcDir);
  for (const f of files) { const to = path.join(resDir, f); fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(path.join(srcDir, f), to); }
  return files;
}
